# Undigital

To start your Phoenix server:

```
asdf install
mix deps.get
mix ecto.setup
cd assets && npm install && cd ..
open http://localhost:4000
mix phx.server
```

# Usage
## API
```
curl localhost:4000/api/grouped_tasks
curl localhost:4000/api/grouped_tasks/:id
curl -H 'Content-Type: application/json' -X POST -d '{"grouped_task": {"group_name": "JohnB", "task_name": "Hello", "completed": "false", "dependent_ids": "[]"}}' localhost:4000/api/grouped_tasks

curl localhost:4000/api/groups
curl localhost:4000/api/groups/:group_name
```

## LiveView
```
open localhost:4000/grouped_tasks
```

# SQL for Table Creation
This SQL is the output from `mix ecto.migrate --log-sql`
after running:

`mix phx.gen.json TaskManagement GroupedTask grouped_tasks group_name:string task_name:string dependency_ids:array:integer completed:boolean`

Note that the `dependency_ids` column is a Postgres array of integers.

```
CREATE TABLE "grouped_tasks" (
    "id" bigserial, 
    "group_name" varchar(255), 
    "task_name" varchar(255), 
    "dependency_ids" integer[], 
    "completed" boolean DEFAULT false NOT NULL, 
    "inserted_at" timestamp(0) NOT NULL, 
    "updated_at" timestamp(0) NOT NULL, 
    PRIMARY KEY ("id")
)
```

# Unhandled Edge Cases
* User is allowed to specify circular dependencies, 
which seems like a bad idea.
* User is allowed to add an incomplete dependency to an already-completed item.

# Scaling Issues
* Both the UI and API could use pagination when the list gets long.

# Challenge

## Requirements
* [x] Build a REST api service that provides task mangement functionality.
* [x] Tasks should be able to be grouped and retrieved by group.
* [x] Tasks should have 3 states
  * Locked
  * Incomplete
  * Complete
* [x] Tasks can be dependent upon other tasks having to be completed first.
  * If a task is dependent upon another task that is not yet complete, the task should be Locked.
  * When a task is locked, it can not be completed.
* [x] API should support
  * Managing all aspects of the tasks and task groups.


## Data Persistence
* You need to persist the data in some way during the app runtime.
* You don't need to use any external persistence for this exercise as it makes it easier for us to run!
* We do care about SQL and schema design so please include the SQL statements you would run to generate your schema.


## Considerations
* Imagine a frontend UI will be consuming the API to provide the UX so you should determine where what business logic lies to perform the requirements.
  * Provide explanation as to why you made certain decisions in your service.
* Keep in mind scale, even if not implemented, we appreciate comments and thoughts on how the service could be optimized for increased scale.

## We value
* Good structured code following best practices
* We're not looking for a hack to get it done.

## Bonus
* [ ] Create a react app that consumes your api and provides a UI.

Once complete, submit a zipped project folder that includes a readme file with any specific instructions on running your solution in addition to any explanation, thoughts, comments etc that you are including with your submission.
