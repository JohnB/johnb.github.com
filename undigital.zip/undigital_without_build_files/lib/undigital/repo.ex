defmodule Undigital.Repo do
  use Ecto.Repo,
    otp_app: :undigital,
    adapter: Ecto.Adapters.Postgres
end
