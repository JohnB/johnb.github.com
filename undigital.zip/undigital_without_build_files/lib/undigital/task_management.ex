defmodule Undigital.TaskManagement do
  @moduledoc """
  The TaskManagement context.
  """

  import Ecto.Query, warn: false
  alias Undigital.Repo

  alias Undigital.TaskManagement.GroupedTask

  @doc """
  Returns the list of grouped_tasks.

  ## Examples

      iex> list_grouped_tasks()
      [%GroupedTask{}, ...]

  """
  def list_grouped_tasks do
    Repo.all(from gt in GroupedTask, order_by: [asc: gt.id])
  end

  @doc """
  Gets a single grouped_task.

  Raises `Ecto.NoResultsError` if the Grouped task does not exist.

  ## Examples

      iex> get_grouped_task!(123)
      %GroupedTask{}

      iex> get_grouped_task!(456)
      ** (Ecto.NoResultsError)

  """
  def get_grouped_task!(id), do: Repo.get!(GroupedTask, id)

  @doc """
  Creates a grouped_task.

  ## Examples

      iex> create_grouped_task(%{field: value})
      {:ok, %GroupedTask{}}

      iex> create_grouped_task(%{field: bad_value})
      {:error, %Ecto.Changeset{}}

  """
  def create_grouped_task(attrs \\ %{}) do
    %GroupedTask{}
    |> GroupedTask.changeset(attrs)
    |> Repo.insert()
  end

  @doc """
  Updates a grouped_task.

  ## Examples

      iex> update_grouped_task(grouped_task, %{field: new_value})
      {:ok, %GroupedTask{}}

      iex> update_grouped_task(grouped_task, %{field: bad_value})
      {:error, %Ecto.Changeset{}}

  """
  def update_grouped_task(%GroupedTask{} = grouped_task, attrs) do
    grouped_task
    |> GroupedTask.changeset(attrs)
    |> Repo.update()
  end

  @doc """
  Deletes a grouped_task.

  ## Examples

      iex> delete_grouped_task(grouped_task)
      {:ok, %GroupedTask{}}

      iex> delete_grouped_task(grouped_task)
      {:error, %Ecto.Changeset{}}

  """
  def delete_grouped_task(%GroupedTask{} = grouped_task) do
    Repo.delete(grouped_task)
  end

  @doc """
  Returns an `%Ecto.Changeset{}` for tracking grouped_task changes.

  ## Examples

      iex> change_grouped_task(grouped_task)
      %Ecto.Changeset{data: %GroupedTask{}}

  """
  def change_grouped_task(%GroupedTask{} = grouped_task, attrs \\ %{}) do
    GroupedTask.changeset(grouped_task, attrs)
  end

  def dependent_tasks(nil), do: []
  def dependent_tasks(dependency_ids) do
    query = from(gt in GroupedTask, where: gt.id in ^dependency_ids)
    Repo.all(query)
  end

  # GROUPS below here
  # Used by:
  #   /api/groups
  #   /api/groups/:id

  def list_groups do
    Repo.all(from gt in GroupedTask,
             select: gt.group_name,
             order_by: [asc: gt.group_name],
             distinct: true
    )
  end

  def get_group(group_name) do
    Repo.all(from gt in GroupedTask,
             where: gt.group_name == ^group_name,
             select: gt.group_name,
             distinct: true
    )
  end
end
