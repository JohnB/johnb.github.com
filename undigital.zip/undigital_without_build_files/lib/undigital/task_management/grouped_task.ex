defmodule Undigital.TaskManagement.GroupedTask do
  use Ecto.Schema
  import Ecto.Changeset

  schema "grouped_tasks" do
    field :completed, :boolean, default: false
    field :dependency_ids, {:array, :integer}
    field :group_name, :string
    field :task_name, :string

    timestamps()
  end

  @doc false
  def changeset(grouped_task, attrs) do
    grouped_task
    |> cast(attrs, [:group_name, :task_name, :dependency_ids, :completed])
    |> validate_required([:group_name, :task_name, :completed])
    |> validate_completed_dependencies()
  end

  def completion_status(grouped_task = %{completed: true}) do
    "Complete"
  end

  def completion_status(grouped_task = %{dependency_ids: []}) do
    "Incomplete"
  end

  def completion_status(grouped_task = %{dependency_ids: dependency_ids}) do
    all_complete?(dependency_ids) && "Incomplete" || "Locked"
  end

  defp validate_completed_dependencies(changeset = %Ecto.Changeset{changes: %{completed: false}}) do
    changeset
  end

  defp validate_completed_dependencies(changeset = %Ecto.Changeset{
    changes: %{completed: true},
    data: %{dependency_ids: []}
  }) do
    changeset
  end

  defp validate_completed_dependencies(changeset = %Ecto.Changeset{
      changes: %{completed: true},
      data: %{dependency_ids: dependency_ids}
    }) do

    if all_complete?(dependency_ids) do
      changeset
    else
      Ecto.Changeset.add_error(changeset, :completed, "complete dependent tasks first")
    end
  end

  defp validate_completed_dependencies(changeset) do
    changeset
  end

  defp all_complete?(dependency_ids) do
    Undigital.TaskManagement.dependent_tasks(dependency_ids)
    |> Enum.all?(fn task -> task.completed end)
  end
end
