defmodule UndigitalWeb.GroupedTaskController do
  use UndigitalWeb, :controller

  alias Undigital.TaskManagement
  alias Undigital.TaskManagement.GroupedTask

  action_fallback UndigitalWeb.FallbackController

  def index(conn, _params) do
    grouped_tasks = TaskManagement.list_grouped_tasks()
    render(conn, "index.json", grouped_tasks: grouped_tasks)
  end

  def create(conn, %{"grouped_task" => grouped_task_params}) do
    with {:ok, %GroupedTask{} = grouped_task} <- TaskManagement.create_grouped_task(grouped_task_params) do
      conn
      |> put_status(:created)
      |> put_resp_header("location", Routes.grouped_task_path(conn, :show, grouped_task))
      |> render("show.json", grouped_task: grouped_task)
    end
  end

  def show(conn, %{"id" => id}) do
    grouped_task = TaskManagement.get_grouped_task!(id)
    render(conn, "show.json", grouped_task: grouped_task)
  end

  def update(conn, %{"id" => id, "grouped_task" => grouped_task_params}) do
    grouped_task = TaskManagement.get_grouped_task!(id)

    with {:ok, %GroupedTask{} = grouped_task} <- TaskManagement.update_grouped_task(grouped_task, grouped_task_params) do
      render(conn, "show.json", grouped_task: grouped_task)
    end
  end

  def delete(conn, %{"id" => id}) do
    grouped_task = TaskManagement.get_grouped_task!(id)

    with {:ok, %GroupedTask{}} <- TaskManagement.delete_grouped_task(grouped_task) do
      send_resp(conn, :no_content, "")
    end
  end
end
