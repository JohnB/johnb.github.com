defmodule UndigitalWeb.GroupsController do
  use UndigitalWeb, :controller

  alias Undigital.TaskManagement
  alias Undigital.TaskManagement.GroupedTask

  action_fallback UndigitalWeb.FallbackController

  def index(conn, _params) do
    groups = TaskManagement.list_groups()
    render(conn, "index.json", groups: groups)
  end

  def show(conn, %{"id" => group_name}) do
    group = TaskManagement.get_group(group_name)
    render(conn, "show.json", group: group)
  end

#  def update(conn, %{"group_name" => group_name, "group" => group_params}) do
#    group = TaskManagement.get_group(group_name)
#
#    with {:ok, %GroupedTask{} = group} <- TaskManagement.update_group(group, group_params) do
#      render(conn, "show.json", group: group)
#    end
#  end
#
#  def delete(conn, %{"group_name" => group_name}) do
#    group = TaskManagement.get_group(group_name)
#
#    with {:ok, %GroupedTask{}} <- TaskManagement.delete_group(group) do
#      send_resp(conn, :no_content, "")
#    end
#  end
end
