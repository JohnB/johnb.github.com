defmodule UndigitalWeb.GroupedTaskLive.FormComponent do
  use UndigitalWeb, :live_component

  alias Undigital.TaskManagement

  @impl true
  def update(%{grouped_task: grouped_task} = assigns, socket) do
    changeset = TaskManagement.change_grouped_task(grouped_task)
    grouped_tasks = TaskManagement.list_grouped_tasks()
    task_ids = Enum.map(grouped_tasks, &( {"#{&1.id}", &1.id} ))

    {:ok,
     socket
     |> assign(assigns)
     |> assign(:changeset, changeset)
     |> assign(:task_ids, task_ids)
    }
  end

  @impl true
  def handle_event("validate", %{"grouped_task" => grouped_task_params}, socket) do
    changeset =
      socket.assigns.grouped_task
      |> TaskManagement.change_grouped_task(grouped_task_params)
      |> Map.put(:action, :validate)

    {:noreply, assign(socket, :changeset, changeset)}
  end

  def handle_event("save", %{"grouped_task" => grouped_task_params}, socket) do
    save_grouped_task(socket, socket.assigns.action, grouped_task_params)
  end

  defp save_grouped_task(socket, :edit, grouped_task_params) do
    case TaskManagement.update_grouped_task(socket.assigns.grouped_task, grouped_task_params) do
      {:ok, _grouped_task} ->
        {:noreply,
         socket
         |> put_flash(:info, "Grouped task updated successfully")
         |> push_redirect(to: socket.assigns.return_to)}

      {:error, %Ecto.Changeset{} = changeset} ->
        {:noreply, assign(socket, :changeset, changeset)}
    end
  end

  defp save_grouped_task(socket, :new, grouped_task_params) do
    case TaskManagement.create_grouped_task(grouped_task_params) do
      {:ok, _grouped_task} ->
        {:noreply,
         socket
         |> put_flash(:info, "Grouped task created successfully")
         |> push_redirect(to: socket.assigns.return_to)}

      {:error, %Ecto.Changeset{} = changeset} ->
        {:noreply, assign(socket, changeset: changeset)}
    end
  end
end
