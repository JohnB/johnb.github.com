defmodule UndigitalWeb.GroupedTaskLive.Index do
  use UndigitalWeb, :live_view

  alias Undigital.TaskManagement
  alias Undigital.TaskManagement.GroupedTask

  @impl true
  def mount(_params, _session, socket) do
    grouped_tasks = list_grouped_tasks()

    {:ok,
      socket
      |> assign(:grouped_tasks, grouped_tasks)
    }
  end

  @impl true
  def handle_params(params, _url, socket) do
    {:noreply, apply_action(socket, socket.assigns.live_action, params)}
  end

  defp apply_action(socket, :edit, %{"id" => id}) do
    socket
    |> assign(:page_title, "Edit Grouped task")
    |> assign(:grouped_task, TaskManagement.get_grouped_task!(id))
  end

  defp apply_action(socket, :new, _params) do
    socket
    |> assign(:page_title, "New Grouped task")
    |> assign(:grouped_task, %GroupedTask{})
  end

  defp apply_action(socket, :index, _params) do
    socket
    |> assign(:page_title, "Listing Grouped tasks")
    |> assign(:grouped_task, nil)
  end

  @impl true
  def handle_event("delete", %{"id" => id}, socket) do
    grouped_task = TaskManagement.get_grouped_task!(id)
    {:ok, _} = TaskManagement.delete_grouped_task(grouped_task)

    {:noreply, assign(socket, :grouped_tasks, list_grouped_tasks())}
  end

  defp list_grouped_tasks do
    TaskManagement.list_grouped_tasks()
  end
end
