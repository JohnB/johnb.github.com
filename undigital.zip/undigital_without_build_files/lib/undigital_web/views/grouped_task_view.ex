defmodule UndigitalWeb.GroupedTaskView do
  use UndigitalWeb, :view
  alias UndigitalWeb.GroupedTaskView

  def render("index.json", %{grouped_tasks: grouped_tasks}) do
    %{data: render_many(grouped_tasks, GroupedTaskView, "grouped_task.json")}
  end

  def render("show.json", %{grouped_task: grouped_task}) do
    %{data: render_one(grouped_task, GroupedTaskView, "grouped_task.json")}
  end

  def render("grouped_task.json", %{grouped_task: grouped_task}) do
    %{id: grouped_task.id,
      group_name: grouped_task.group_name,
      task_name: grouped_task.task_name,
      dependency_ids: grouped_task.dependency_ids,
      completed: grouped_task.completed}
  end
end
