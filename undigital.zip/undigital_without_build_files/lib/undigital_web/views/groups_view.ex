defmodule UndigitalWeb.GroupsView do
  use UndigitalWeb, :view
  alias UndigitalWeb.GroupsView

  def render("index.json", %{groups: groups}) do
    %{data: render_many(groups, GroupsView, "group.json")}
  end

  def render("group.json", %{groups: group_name}) do
    %{group_name: group_name}
  end

  def render("show.json", %{group: group_name}) do
    %{data: %{group_name: group_name}}
  end
end
