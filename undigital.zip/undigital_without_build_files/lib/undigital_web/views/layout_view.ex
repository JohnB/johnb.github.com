defmodule UndigitalWeb.LayoutView do
  use UndigitalWeb, :view
end
