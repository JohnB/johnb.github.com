defmodule Undigital.Repo.Migrations.CreateGroupedTasks do
  use Ecto.Migration

  def change do
    create table(:grouped_tasks) do
      add :group_name, :string
      add :task_name, :string
      add :dependency_ids, {:array, :integer}
      add :completed, :boolean, default: false, null: false

      timestamps()
    end

  end
end
