defmodule Undigital.TaskManagementTest do
  use Undigital.DataCase

  alias Undigital.TaskManagement

  describe "grouped_tasks" do
    alias Undigital.TaskManagement.GroupedTask

    @valid_attrs %{completed: true, dependency_ids: [], group_name: "some group_name", task_name: "some task_name"}
    @update_attrs %{completed: false, dependency_ids: [], group_name: "some updated group_name", task_name: "some updated task_name"}
    @invalid_attrs %{completed: nil, dependency_ids: nil, group_name: nil, task_name: nil}

    def grouped_task_fixture(attrs \\ %{}) do
      {:ok, grouped_task} =
        attrs
        |> Enum.into(@valid_attrs)
        |> TaskManagement.create_grouped_task()

      grouped_task
    end

    test "list_grouped_tasks/0 returns all grouped_tasks" do
      grouped_task = grouped_task_fixture()
      assert TaskManagement.list_grouped_tasks() == [grouped_task]
    end

    test "get_grouped_task!/1 returns the grouped_task with given id" do
      grouped_task = grouped_task_fixture()
      assert TaskManagement.get_grouped_task!(grouped_task.id) == grouped_task
    end

    test "create_grouped_task/1 with valid data creates a grouped_task" do
      assert {:ok, %GroupedTask{} = grouped_task} = TaskManagement.create_grouped_task(@valid_attrs)
      assert grouped_task.completed == true
      assert grouped_task.dependency_ids == []
      assert grouped_task.group_name == "some group_name"
      assert grouped_task.task_name == "some task_name"
    end

    test "create_grouped_task/1 with invalid data returns error changeset" do
      assert {:error, %Ecto.Changeset{}} = TaskManagement.create_grouped_task(@invalid_attrs)
    end

    test "update_grouped_task/2 with valid data updates the grouped_task" do
      grouped_task = grouped_task_fixture()
      assert {:ok, %GroupedTask{} = grouped_task} = TaskManagement.update_grouped_task(grouped_task, @update_attrs)
      assert grouped_task.completed == false
      assert grouped_task.dependency_ids == []
      assert grouped_task.group_name == "some updated group_name"
      assert grouped_task.task_name == "some updated task_name"
    end

    test "update_grouped_task/2 with invalid data returns error changeset" do
      grouped_task = grouped_task_fixture()
      assert {:error, %Ecto.Changeset{}} = TaskManagement.update_grouped_task(grouped_task, @invalid_attrs)
      assert grouped_task == TaskManagement.get_grouped_task!(grouped_task.id)
    end

    test "update_grouped_task/2 as completed with no dependencies returns success changeset" do
      grouped_task = grouped_task_fixture()
      assert {:ok, result = %Undigital.TaskManagement.GroupedTask{}} =
               TaskManagement.update_grouped_task(grouped_task, %{completed: true})
      assert result == TaskManagement.get_grouped_task!(grouped_task.id)
      assert grouped_task == TaskManagement.get_grouped_task!(grouped_task.id)
    end

    test "update_grouped_task/2 as completed with completed dependencies returns success changeset" do
      grouped_task = grouped_task_fixture(completed: false)
      assert {:ok, result = %Undigital.TaskManagement.GroupedTask{}} =
               TaskManagement.update_grouped_task(grouped_task, %{completed: true})
      assert result == TaskManagement.get_grouped_task!(grouped_task.id)

      grouped_task2 = grouped_task_fixture(dependency_ids: [grouped_task.id], completed: false)
      assert {:ok, result = %Undigital.TaskManagement.GroupedTask{}} =
               TaskManagement.update_grouped_task(grouped_task2, %{completed: true})
    end

    test "update_grouped_task/2 as completed with UNcompleted dependencies returns error changeset" do
      grouped_task = grouped_task_fixture(completed: false)
      grouped_task2 = grouped_task_fixture(completed: false, dependency_ids: [grouped_task.id])
      assert {:error, err = %Ecto.Changeset{}} =
               TaskManagement.update_grouped_task(grouped_task2, %{completed: true})
    end

    test "delete_grouped_task/1 deletes the grouped_task" do
      grouped_task = grouped_task_fixture()
      assert {:ok, %GroupedTask{}} = TaskManagement.delete_grouped_task(grouped_task)
      assert_raise Ecto.NoResultsError, fn -> TaskManagement.get_grouped_task!(grouped_task.id) end
    end

    test "change_grouped_task/1 returns a grouped_task changeset" do
      grouped_task = grouped_task_fixture()
      assert %Ecto.Changeset{} = TaskManagement.change_grouped_task(grouped_task)
    end
  end
end
