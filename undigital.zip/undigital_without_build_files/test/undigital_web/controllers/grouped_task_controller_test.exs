defmodule UndigitalWeb.GroupedTaskControllerTest do
  use UndigitalWeb.ConnCase

  alias Undigital.TaskManagement
  alias Undigital.TaskManagement.GroupedTask

  @create_attrs %{
    completed: true,
    dependency_ids: [],
    group_name: "some group_name",
    task_name: "some task_name"
  }
  @update_attrs %{
    completed: false,
    dependency_ids: [],
    group_name: "some updated group_name",
    task_name: "some updated task_name"
  }
  @invalid_attrs %{completed: nil, dependency_ids: nil, group_name: nil, task_name: nil}

  def fixture(:grouped_task) do
    {:ok, grouped_task} = TaskManagement.create_grouped_task(@create_attrs)
    grouped_task
  end

  setup %{conn: conn} do
    {:ok, conn: put_req_header(conn, "accept", "application/json")}
  end

  describe "index" do
    test "lists all grouped_tasks", %{conn: conn} do
      conn = get(conn, Routes.grouped_task_path(conn, :index))
      assert json_response(conn, 200)["data"] == []
    end
  end

  describe "create grouped_task" do
    test "renders grouped_task when data is valid", %{conn: conn} do
      conn = post(conn, Routes.grouped_task_path(conn, :create), grouped_task: @create_attrs)
      assert %{"id" => id} = json_response(conn, 201)["data"]

      conn = get(conn, Routes.grouped_task_path(conn, :show, id))

      assert %{
               "id" => id,
               "completed" => true,
               "dependency_ids" => [],
               "group_name" => "some group_name",
               "task_name" => "some task_name"
             } = json_response(conn, 200)["data"]
    end

    test "renders errors when data is invalid", %{conn: conn} do
      conn = post(conn, Routes.grouped_task_path(conn, :create), grouped_task: @invalid_attrs)
      assert json_response(conn, 422)["errors"] != %{}
    end
  end

  describe "update grouped_task" do
    setup [:create_grouped_task]

    test "renders grouped_task when data is valid", %{conn: conn, grouped_task: %GroupedTask{id: id} = grouped_task} do
      conn = put(conn, Routes.grouped_task_path(conn, :update, grouped_task), grouped_task: @update_attrs)
      assert %{"id" => ^id} = json_response(conn, 200)["data"]

      conn = get(conn, Routes.grouped_task_path(conn, :show, id))

      assert %{
               "id" => id,
               "completed" => false,
               "dependency_ids" => [],
               "group_name" => "some updated group_name",
               "task_name" => "some updated task_name"
             } = json_response(conn, 200)["data"]
    end

    test "renders errors when data is invalid", %{conn: conn, grouped_task: grouped_task} do
      conn = put(conn, Routes.grouped_task_path(conn, :update, grouped_task), grouped_task: @invalid_attrs)
      assert json_response(conn, 422)["errors"] != %{}
    end
  end

  describe "delete grouped_task" do
    setup [:create_grouped_task]

    test "deletes chosen grouped_task", %{conn: conn, grouped_task: grouped_task} do
      conn = delete(conn, Routes.grouped_task_path(conn, :delete, grouped_task))
      assert response(conn, 204)

      assert_error_sent 404, fn ->
        get(conn, Routes.grouped_task_path(conn, :show, grouped_task))
      end
    end
  end

  defp create_grouped_task(_) do
    grouped_task = fixture(:grouped_task)
    %{grouped_task: grouped_task}
  end
end
