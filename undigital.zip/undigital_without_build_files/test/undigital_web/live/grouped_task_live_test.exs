defmodule UndigitalWeb.GroupedTaskLiveTest do
  use UndigitalWeb.ConnCase

  import Phoenix.LiveViewTest

  alias Undigital.TaskManagement

  @create_attrs %{completed: true, dependency_ids: [], group_name: "some group_name", task_name: "some task_name"}
  @update_attrs %{completed: false, dependency_ids: [], group_name: "some updated group_name", task_name: "some updated task_name"}
  @invalid_attrs %{completed: false, dependency_ids: [], group_name: nil, task_name: nil}

  defp fixture(:grouped_task) do
    {:ok, grouped_task} = TaskManagement.create_grouped_task(@create_attrs)
    grouped_task
  end

  defp create_grouped_task(_) do
    grouped_task = fixture(:grouped_task)
    %{grouped_task: grouped_task}
  end

  describe "Index" do
    setup [:create_grouped_task]

    test "lists all grouped_tasks", %{conn: conn, grouped_task: grouped_task} do
      {:ok, _index_live, html} = live(conn, Routes.grouped_task_index_path(conn, :index))

      assert html =~ "Listing Grouped tasks"
      assert html =~ grouped_task.group_name
    end

    test "saves new grouped_task", %{conn: conn} do
      {:ok, index_live, _html} = live(conn, Routes.grouped_task_index_path(conn, :index))

      assert index_live |> element("a", "New Grouped task") |> render_click() =~
               "New Grouped task"

      assert_patch(index_live, Routes.grouped_task_index_path(conn, :new))

      assert index_live
             |> form("#grouped_task-form", grouped_task: @invalid_attrs)
             |> render_change() =~ "can&apos;t be blank"

      {:ok, _, html} =
        index_live
        |> form("#grouped_task-form", grouped_task: @create_attrs)
        |> render_submit()
        |> follow_redirect(conn, Routes.grouped_task_index_path(conn, :index))

      assert html =~ "Grouped task created successfully"
      assert html =~ "some group_name"
    end

    test "updates grouped_task in listing", %{conn: conn, grouped_task: grouped_task} do
      {:ok, index_live, _html} = live(conn, Routes.grouped_task_index_path(conn, :index))

      assert index_live |> element("#grouped_task-#{grouped_task.id} a", "Edit") |> render_click() =~
               "Edit Grouped task"

      assert_patch(index_live, Routes.grouped_task_index_path(conn, :edit, grouped_task))

      assert index_live
             |> form("#grouped_task-form", grouped_task: @invalid_attrs)
             |> render_change() =~ "can&apos;t be blank"

      {:ok, _, html} =
        index_live
        |> form("#grouped_task-form", grouped_task: @update_attrs)
        |> render_submit()
        |> follow_redirect(conn, Routes.grouped_task_index_path(conn, :index))

      assert html =~ "Grouped task updated successfully"
      assert html =~ "some updated group_name"
    end

    test "deletes grouped_task in listing", %{conn: conn, grouped_task: grouped_task} do
      {:ok, index_live, _html} = live(conn, Routes.grouped_task_index_path(conn, :index))

      assert index_live |> element("#grouped_task-#{grouped_task.id} a", "Delete") |> render_click()
      refute has_element?(index_live, "#grouped_task-#{grouped_task.id}")
    end
  end

  describe "Show" do
    setup [:create_grouped_task]

    test "displays grouped_task", %{conn: conn, grouped_task: grouped_task} do
      {:ok, _show_live, html} = live(conn, Routes.grouped_task_show_path(conn, :show, grouped_task))

      assert html =~ "Show Grouped task"
      assert html =~ grouped_task.group_name
    end

    test "updates grouped_task within modal", %{conn: conn, grouped_task: grouped_task} do
      {:ok, show_live, _html} = live(conn, Routes.grouped_task_show_path(conn, :show, grouped_task))

      assert show_live |> element("a", "Edit") |> render_click() =~
               "Edit Grouped task"

      assert_patch(show_live, Routes.grouped_task_show_path(conn, :edit, grouped_task))

      assert show_live
             |> form("#grouped_task-form", grouped_task: @invalid_attrs)
             |> render_change() =~ "can&apos;t be blank"

      {:ok, _, html} =
        show_live
        |> form("#grouped_task-form", grouped_task: @update_attrs)
        |> render_submit()
        |> follow_redirect(conn, Routes.grouped_task_show_path(conn, :show, grouped_task))

      assert html =~ "Grouped task updated successfully"
      assert html =~ "some updated group_name"
    end
  end
end
