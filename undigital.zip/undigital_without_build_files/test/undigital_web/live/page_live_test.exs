defmodule UndigitalWeb.PageLiveTest do
  use UndigitalWeb.ConnCase

  import Phoenix.LiveViewTest

  test "disconnected and connected render", %{conn: conn} do
    {:ok, _page_live, disconnected_html} = live(conn, "/")
    assert disconnected_html =~ "Phoenix Framework"
  end
end
